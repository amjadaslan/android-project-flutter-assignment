package com.technion.android.hellome.hello_me1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
