import 'package:flutter/material.dart';
import 'package:hello_me/auth.dart';
import 'package:provider/provider.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController? _email = new TextEditingController();
  TextEditingController? _password = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<AuthRepository>(context);
    return Scaffold(
        appBar: AppBar(
          title: const Center(child: Text('Login              ')),
        ),
        body: Center(
            child: SizedBox(
                width: 350,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const SizedBox(height: 20),
                      const Text(
                          'Welcome to Startup Names Generator, please log in below'),
                      const SizedBox(height: 20),
                      TextField(
                          controller: _email,
                          decoration: InputDecoration(
                            hintText: 'Email',
                          )),
                      const SizedBox(height: 20),
                      TextField(
                          controller: _password,
                          obscureText: true,
                          decoration: InputDecoration(
                            hintText: 'Password',
                          )),
                      const SizedBox(height: 10),
                      user.status == Status.Authenticating
                          ? Center(child: CircularProgressIndicator())
                          : TextButton(
                              onPressed: () async {
                                if (await user.signIn(
                                    _email!.text, _password!.text)) {
                                  Navigator.pop(context);
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                          content: Text(
                                              'There was an error logging into the app.')));
                                }
                              },
                              style: TextButton.styleFrom(
                                  primary: Colors.white,
                                  fixedSize: const Size(350, 20),
                                  shape: const StadiumBorder(),
                                  backgroundColor: Colors.deepPurple),
                              child: const Text('Login'))
                    ]))));
  }
}
